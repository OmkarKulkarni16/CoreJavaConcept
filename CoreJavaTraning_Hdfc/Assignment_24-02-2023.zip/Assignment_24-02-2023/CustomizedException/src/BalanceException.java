public class BalanceException extends Exception {
BalanceException(String s){
    super(s);
}
}
