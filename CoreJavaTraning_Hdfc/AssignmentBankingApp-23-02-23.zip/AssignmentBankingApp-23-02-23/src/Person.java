
public class Person {
    private String name;
    private float age;

    @Override
    public String toString() {
        return "Person" +
                "name = '" + name + '\'' +
                ", age = " + age;
    }

    public Person(String name, float age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getAge() {
        return age;
    }

    public void setAge(float age) {
        this.age = age;
    }
}

//public class Person extends Account{
//
//    private String name;
//    private float age;
//
//
//
//
//    public String getName() {
//        return name;
//    }
//
//    public void setName(String name) {
//        super.setAccHolder(name);
//        this.name = name;
//    }
//
//    public float getAge() {
//        return age;
//    }
//
//    public void setAge(float age) {
//        this.age = age;
//    }
//
//    @Override
//    public void withdraw(double withdrawAmount) {
//        super.withdraw(withdrawAmount);
//    }
//
//    @Override
//    public void deposit(double amount) {
//        super.deposit(amount);
//    }
//
//    @Override
//    public void setAccountNumber(long accountNumber) {
//        long leftLimit = 1L;
//        long rightLimit = 1L;
//        long generatedLong = leftLimit + (long) (Math.random() * (rightLimit - leftLimit));
//        super.setAccountNumber(generatedLong + accountNumber);
//    }
//
//    @Override
//    public String toString() {
//        return "Person{" +
//                "name='" + name + '\'' +
//                ", age=" + age +
//                  super.toString();
//    }
//}
