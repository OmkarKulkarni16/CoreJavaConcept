//public class SavingAccount extends Account {
//
//    final long minimumBalance = 500;
//
//
//    @Override
//    public void deposit(double amount) {
//        super.deposit(amount);
//    }
//
//    @Override
//    public void withdraw(double withdrawAmount) {
//        if (minimumBalance > 2000) {
//            super.withdraw(withdrawAmount);
//        }else{
//            System.out.println("Sorry Your Minimum Balance is " + minimumBalance + " Withdraw declined");
//        }
//    }
//}
